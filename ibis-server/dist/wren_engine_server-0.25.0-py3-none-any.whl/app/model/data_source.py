from __future__ import annotations

import base64
import ssl
import urllib
from enum import Enum, StrEnum, auto
from json import loads
from typing import Any
from urllib.parse import unquote_plus

import boto3
import ibis
from google.cloud import bigquery
from google.oauth2 import service_account
from ibis import BaseBackend

from app.model import (
    AthenaConnectionInfo,
    BigQueryDatasetConnectionInfo,
    BigQueryProjectConnectionInfo,
    CannerConnectionInfo,
    ClickHouseConnectionInfo,
    ConnectionInfo,
    ConnectionUrl,
    DatabricksServicePrincipalConnectionInfo,
    DatabricksTokenConnectionInfo,
    DorisConnectionInfo,
    GcsFileConnectionInfo,
    LocalFileConnectionInfo,
    MinioFileConnectionInfo,
    MSSqlConnectionInfo,
    MySqlConnectionInfo,
    OracleConnectionInfo,
    PostgresConnectionInfo,
    QueryAthenaDTO,
    QueryBigQueryDTO,
    QueryCannerDTO,
    QueryClickHouseDTO,
    QueryDatabricksDTO,
    QueryDorisDTO,
    QueryDTO,
    QueryDuckDBDTO,
    QueryGcsFileDTO,
    QueryLocalFileDTO,
    QueryMinioFileDTO,
    QueryMSSqlDTO,
    QueryMySqlDTO,
    QueryOracleDTO,
    QueryPostgresDTO,
    QueryRedshiftDTO,
    QueryS3FileDTO,
    QuerySnowflakeDTO,
    QuerySparkDTO,
    QueryTrinoDTO,
    RedshiftConnectionInfo,
    RedshiftIAMConnectionInfo,
    S3FileConnectionInfo,
    SnowflakeConnectionInfo,
    SparkConnectionInfo,
    SSLMode,
    TrinoConnectionInfo,
)
from app.model.error import ErrorCode, WrenError

X_WREN_DB_STATEMENT_TIMEOUT = "x-wren-db-statement_timeout"


class DataSource(StrEnum):
    athena = auto()
    bigquery = auto()
    canner = auto()
    clickhouse = auto()
    mssql = auto()
    mysql = auto()
    doris = auto()
    oracle = auto()
    postgres = auto()
    redshift = auto()
    snowflake = auto()
    trino = auto()
    local_file = auto()
    s3_file = auto()
    minio_file = auto()
    gcs_file = auto()
    duckdb = auto()
    spark = auto()
    databricks = auto()

    def get_connection(self, info: ConnectionInfo) -> BaseBackend:
        try:
            return DataSourceExtension[self].get_connection(info)
        except KeyError:
            raise NotImplementedError(f"Unsupported data source: {self}")

    def get_dto_type(self):
        try:
            return DataSourceExtension[self].dto
        except KeyError:
            raise NotImplementedError(f"Unsupported data source: {self}")

    def get_connection_info(
        self,
        data: dict[str, Any] | ConnectionInfo,
        headers: dict[str, str] | None = None,
    ) -> ConnectionInfo:
        """Build a ConnectionInfo object from the provided data and add requried configuration from headers."""

        headers = headers or {}
        if isinstance(data, ConnectionInfo):
            info = data
        else:
            info = self._build_connection_info(data)
        match self:
            case DataSource.postgres:
                kwargs = info.kwargs if info.kwargs else dict()
                if not hasattr(info, "connect_timeout"):
                    kwargs["connect_timeout"] = 120

                options = kwargs.get("options", "")
                if "statement_timeout" not in options:
                    if options:
                        options += " "
                    options += f"-c statement_timeout={headers.get(X_WREN_DB_STATEMENT_TIMEOUT, 180)}s"
                    kwargs["options"] = options
                info.kwargs = kwargs
            case DataSource.clickhouse:
                session_timeout = headers.get(X_WREN_DB_STATEMENT_TIMEOUT, 180)
                if info.settings is None:
                    info.settings = {}
                if "max_execution_time" not in info.settings:
                    info.settings["max_execution_time"] = int(session_timeout)
            case DataSource.trino:
                session_timeout = headers.get(X_WREN_DB_STATEMENT_TIMEOUT, 180)
                if info.kwargs is None:
                    info.kwargs = {}
                session_properties = info.kwargs.get("session_properties", {})
                if "query_max_execution_time" not in session_properties:
                    session_properties["query_max_execution_time"] = (
                        f"{session_timeout}s"
                    )
                info.kwargs["session_properties"] = session_properties
            case DataSource.bigquery:
                session_timeout = headers.get(X_WREN_DB_STATEMENT_TIMEOUT, 180)
                if not hasattr(info, "job_timeout_ms") or info.job_timeout_ms is None:
                    info.job_timeout_ms = int(session_timeout) * 1000
        return info

    def _build_connection_info(self, data: dict) -> ConnectionInfo:
        """Build a ConnectionInfo object from the provided data."""
        # Check if data contains connectionUrl for connection string-based connections
        if "connectionUrl" in data or "connection_url" in data:
            if self == DataSource.clickhouse:
                return self._handle_clickhouse_url(
                    urllib.parse.urlparse(
                        data.get("connectionUrl", data.get("connection_url"))
                    )
                )
            return ConnectionUrl.model_validate(data)

        match self:
            case DataSource.athena:
                return AthenaConnectionInfo.model_validate(data)
            case DataSource.bigquery:
                if "bigquery_type" in data and data["bigquery_type"] == "project":
                    return BigQueryProjectConnectionInfo.model_validate(data)
                return BigQueryDatasetConnectionInfo.model_validate(data)
            case DataSource.canner:
                return CannerConnectionInfo.model_validate(data)
            case DataSource.clickhouse:
                return ClickHouseConnectionInfo.model_validate(data)
            case DataSource.mssql:
                return MSSqlConnectionInfo.model_validate(data)
            case DataSource.mysql:
                return MySqlConnectionInfo.model_validate(data)
            case DataSource.doris:
                return DorisConnectionInfo.model_validate(data)
            case DataSource.oracle:
                return OracleConnectionInfo.model_validate(data)
            case DataSource.postgres:
                return PostgresConnectionInfo.model_validate(data)
            case DataSource.redshift:
                if "redshift_type" in data and data["redshift_type"] == "redshift_iam":
                    return RedshiftIAMConnectionInfo.model_validate(data)
                return RedshiftConnectionInfo.model_validate(data)
            case DataSource.snowflake:
                return SnowflakeConnectionInfo.model_validate(data)
            case DataSource.trino:
                return TrinoConnectionInfo.model_validate(data)
            case DataSource.duckdb:
                return LocalFileConnectionInfo.model_validate(data)
            case DataSource.local_file:
                return LocalFileConnectionInfo.model_validate(data)
            case DataSource.s3_file:
                return S3FileConnectionInfo.model_validate(data)
            case DataSource.minio_file:
                return MinioFileConnectionInfo.model_validate(data)
            case DataSource.gcs_file:
                return GcsFileConnectionInfo.model_validate(data)
            case DataSource.spark:
                return SparkConnectionInfo.model_validate(data)
            case DataSource.databricks:
                if (
                    "databricks_type" in data
                    and data["databricks_type"] == "service_principal"
                ):
                    return DatabricksServicePrincipalConnectionInfo.model_validate(data)
                return DatabricksTokenConnectionInfo.model_validate(data)
            case _:
                raise NotImplementedError(f"Unsupported data source: {self}")

    def _handle_clickhouse_url(
        self, parsed: urllib.parse.ParseResult
    ) -> ClickHouseConnectionInfo:
        if not parsed.scheme or parsed.scheme != "clickhouse":
            raise WrenError(
                ErrorCode.INVALID_CONNECTION_INFO,
                "Invalid connection URL for ClickHouse",
            )
        kwargs = {}
        if parsed.username:
            kwargs["user"] = parsed.username
        if parsed.password:
            kwargs["password"] = unquote_plus(parsed.password)
        if parsed.hostname:
            kwargs["host"] = parsed.hostname
        if parsed.port:
            kwargs["port"] = str(parsed.port)
        if database := parsed.path[1:]:
            kwargs["database"] = database
        parsed_kwargs = dict(urllib.parse.parse_qsl(parsed.query))
        if "secure" in parsed_kwargs:
            kwargs["secure"] = self._safe_strtobool(parsed_kwargs["secure"])
            parsed_kwargs.pop("secure")
        kwargs["kwargs"] = parsed_kwargs
        return ClickHouseConnectionInfo(**kwargs)

    def _safe_strtobool(self, val: str) -> bool:
        return val.lower() in {"1", "true", "yes", "y"}


class DataSourceExtension(Enum):
    athena = QueryAthenaDTO
    bigquery = QueryBigQueryDTO
    canner = QueryCannerDTO
    clickhouse = QueryClickHouseDTO
    mssql = QueryMSSqlDTO
    mysql = QueryMySqlDTO
    doris = QueryDorisDTO
    oracle = QueryOracleDTO
    postgres = QueryPostgresDTO
    redshift = QueryRedshiftDTO
    snowflake = QuerySnowflakeDTO
    trino = QueryTrinoDTO
    local_file = QueryLocalFileDTO
    duckdb = QueryDuckDBDTO
    s3_file = QueryS3FileDTO
    minio_file = QueryMinioFileDTO
    gcs_file = QueryGcsFileDTO
    databricks = QueryDatabricksDTO
    spark = QuerySparkDTO

    def __init__(self, dto: QueryDTO):
        self.dto = dto

    def get_connection(self, info: ConnectionInfo) -> BaseBackend:
        try:
            if hasattr(info, "connection_url"):
                kwargs = info.kwargs if info.kwargs else {}
                return ibis.connect(info.connection_url.get_secret_value(), **kwargs)
            if self.name in {"local_file", "redshift", "spark", "duckdb"}:
                raise NotImplementedError(
                    f"{self.name} connection is not implemented to get ibis backend"
                )
            return getattr(self, f"get_{self.name}_connection")(info)
        except KeyError:
            raise NotImplementedError(f"Unsupported data source: {self}")
        except WrenError:
            raise
        except Exception as e:
            raise WrenError(ErrorCode.GET_CONNECTION_ERROR, f"{e!s}") from e

    @staticmethod
    def get_athena_connection(info: AthenaConnectionInfo) -> BaseBackend:
        kwargs: dict[str, Any] = {
            "s3_staging_dir": info.s3_staging_dir.get_secret_value(),
            "schema_name": info.schema_name.get_secret_value(),
        }

        # ── Region ────────────────────────────────────────────────
        if info.region_name:
            kwargs["region_name"] = info.region_name.get_secret_value()

        # ── Web Identity Token flow (Google OIDC → AWS STS) ───
        if info.web_identity_token and info.role_arn:
            oidc_token = info.web_identity_token.get_secret_value()
            role_arn = info.role_arn.get_secret_value()
            session_name = (
                info.role_session_name.get_secret_value()
                if info.role_session_name
                else "wren-oidc-session"
            )
            region = info.region_name.get_secret_value() if info.region_name else None
            sts = boto3.client("sts", region_name=region)

            resp = sts.assume_role_with_web_identity(
                RoleArn=role_arn,
                RoleSessionName=session_name,
                WebIdentityToken=oidc_token,
            )

            creds = resp["Credentials"]
            kwargs["aws_access_key_id"] = creds["AccessKeyId"]
            kwargs["aws_secret_access_key"] = creds["SecretAccessKey"]
            kwargs["aws_session_token"] = creds["SessionToken"]

        # ── Standard Access/Secret Keys ───────────────────────
        elif info.aws_access_key_id and info.aws_secret_access_key:
            kwargs["aws_access_key_id"] = info.aws_access_key_id.get_secret_value()
            kwargs["aws_secret_access_key"] = (
                info.aws_secret_access_key.get_secret_value()
            )
            if info.aws_session_token:
                kwargs["aws_session_token"] = info.aws_session_token.get_secret_value()

        # ── 3️⃣ Default AWS credential chain ───────────────────────
        # Nothing needed — PyAthena automatically falls back to:
        #   - Environment variables
        #   - ~/.aws/credentials
        #   - IAM Role (EC2, ECS, Lambda)

        # Now connect via Ibis wrapper
        return ibis.athena.connect(**kwargs)

    @staticmethod
    def get_bigquery_connection(info: BigQueryDatasetConnectionInfo) -> BaseBackend:
        credits_json = loads(
            base64.b64decode(info.credentials.get_secret_value()).decode("utf-8")
        )
        credentials = service_account.Credentials.from_service_account_info(
            credits_json
        )
        credentials = credentials.with_scopes(
            [
                "https://www.googleapis.com/auth/drive",
                "https://www.googleapis.com/auth/cloud-platform",
            ]
        )
        bq_client = bigquery.Client(
            project=info.project_id.get_secret_value(), credentials=credentials
        )
        job_config = bigquery.QueryJobConfig()
        job_config.job_timeout_ms = info.job_timeout_ms
        bq_client.default_query_job_config = job_config
        backend = ibis.bigquery.connect(client=bq_client, credentials=credentials)
        return backend

    @staticmethod
    def get_canner_connection(info: CannerConnectionInfo) -> BaseBackend:
        return ibis.postgres.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.workspace.get_secret_value(),
            user=info.user.get_secret_value(),
            password=info.pat.get_secret_value(),
        )

    @staticmethod
    def get_clickhouse_connection(info: ClickHouseConnectionInfo) -> BaseBackend:
        return ibis.clickhouse.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=(info.password and info.password.get_secret_value()),
            settings=info.settings if info.settings else dict(),
            **info.kwargs if info.kwargs else dict(),
        )

    @classmethod
    def get_mssql_connection(cls, info: MSSqlConnectionInfo) -> BaseBackend:
        return ibis.mssql.connect(
            host=info.host.get_secret_value(),
            port=info.port.get_secret_value(),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=info.password.get_secret_value(),
            driver=info.driver,
            TDS_Version=info.tds_version,
            **info.kwargs if info.kwargs else dict(),
        )

    @classmethod
    def get_mysql_connection(cls, info: MySqlConnectionInfo) -> BaseBackend:
        ssl_context = cls._create_ssl_context(info)
        kwargs = {"ssl": ssl_context} if ssl_context else {}

        # utf8mb4 is the actual charset used by MySQL for utf8
        kwargs.setdefault("charset", "utf8mb4")

        if info.kwargs:
            kwargs.update(info.kwargs)
        return ibis.mysql.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=info.password.get_secret_value() if info.password else "",
            **kwargs,
        )

    @classmethod
    def get_doris_connection(cls, info: DorisConnectionInfo) -> BaseBackend:
        kwargs = {}

        # utf8mb4 is the actual charset used by Doris (MySQL-compatible)
        kwargs.setdefault("charset", "utf8mb4")

        if info.kwargs:
            kwargs.update(info.kwargs)
        # Doris is MySQL-protocol compatible, reuse ibis.mysql.connect()
        connection = ibis.mysql.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=info.password.get_secret_value() if info.password else "",
            **kwargs,
        )
        # Doris does not properly reflect the SERVER_STATUS_AUTOCOMMIT flag
        # in its MySQL-protocol handshake/OK packets. As a result, the
        # underlying mysqlclient driver's get_autocommit() always returns
        # False — even after explicitly calling autocommit(True).
        #
        # ibis's raw_sql() checks get_autocommit() and, when it returns
        # False, wraps every query in BEGIN/ROLLBACK. Doris (an OLAP engine)
        # does not support transactional SELECT inside BEGIN and will reject
        # with: "This is in a transaction, only insert, update, delete,
        # commit, rollback is acceptable."
        #
        # Fix: override get_autocommit on THIS connection instance only so
        # that ibis skips the BEGIN/ROLLBACK wrapping. This is a per-object
        # attribute override — it does NOT affect the MySQLdb class, other
        # MySQL connections, or any other data-source driver.
        connection.con.get_autocommit = lambda: True
        return connection

    @staticmethod
    def get_postgres_connection(info: PostgresConnectionInfo) -> BaseBackend:
        return ibis.postgres.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=(info.password and info.password.get_secret_value()),
            **info.kwargs if info.kwargs else dict(),
        )

    @staticmethod
    def get_oracle_connection(info: OracleConnectionInfo) -> BaseBackend:
        # if dsn is provided, use it to connect
        # otherwise, use host, port, database, user, password, and sid
        if hasattr(info, "dsn") and info.dsn:
            return ibis.oracle.connect(
                dsn=info.dsn.get_secret_value(),
                user=info.user.get_secret_value(),
                password=(info.password and info.password.get_secret_value()),
            )
        return ibis.oracle.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.database.get_secret_value(),
            user=info.user.get_secret_value(),
            password=(info.password and info.password.get_secret_value()),
        )

    @staticmethod
    def get_snowflake_connection(info: SnowflakeConnectionInfo) -> BaseBackend:
        # private key authentication
        if hasattr(info, "private_key") and info.private_key:
            connection_params = {
                "user": info.user.get_secret_value(),
                "private_key": info.private_key.get_secret_value(),
                "account": info.account.get_secret_value(),
                "database": info.database.get_secret_value(),
                "schema": info.sf_schema.get_secret_value(),
            }
            # warehouse if it exists and is not None/empty
            if hasattr(info, "warehouse") and info.warehouse:
                connection_params["warehouse"] = info.warehouse.get_secret_value()
            if info.kwargs:
                connection_params.update(info.kwargs)
            return ibis.snowflake.connect(**connection_params)
        else:
            # password authentication
            connection_params = {
                "user": info.user.get_secret_value(),
                "password": info.password.get_secret_value(),
                "account": info.account.get_secret_value(),
                "database": info.database.get_secret_value(),
                "schema": info.sf_schema.get_secret_value(),
            }

        # warehouse if it exists and is not None/empty
        if hasattr(info, "warehouse") and info.warehouse:
            connection_params["warehouse"] = info.warehouse.get_secret_value()
        if info.kwargs:
            connection_params.update(info.kwargs)
        return ibis.snowflake.connect(**connection_params)

    @staticmethod
    def get_trino_connection(info: TrinoConnectionInfo) -> BaseBackend:
        return ibis.trino.connect(
            host=info.host.get_secret_value(),
            port=int(info.port.get_secret_value()),
            database=info.catalog.get_secret_value(),
            schema=info.trino_schema.get_secret_value(),
            user=(info.user and info.user.get_secret_value()),
            password=(info.password and info.password.get_secret_value()),
            **info.kwargs if info.kwargs else dict(),
        )

    @staticmethod
    def get_databricks_connection(info: DatabricksTokenConnectionInfo) -> BaseBackend:
        return ibis.databricks.connect(
            server_hostname=info.server_hostname.get_secret_value(),
            http_path=info.http_path.get_secret_value(),
            access_token=info.access_token.get_secret_value(),
        )

    @staticmethod
    def _create_ssl_context(info: ConnectionInfo) -> ssl.SSLContext | None:
        ssl_mode = (
            info.ssl_mode.get_secret_value()
            if hasattr(info, "ssl_mode") and info.ssl_mode
            else None
        )

        if ssl_mode == SSLMode.VERIFY_CA and not info.ssl_ca:
            raise WrenError(
                ErrorCode.INVALID_CONNECTION_INFO,
                "SSL CA must be provided when SSL mode is VERIFY CA",
            )

        if not ssl_mode or ssl_mode == SSLMode.DISABLED:
            return None

        ctx = ssl.create_default_context()
        ctx.check_hostname = False

        if ssl_mode == SSLMode.ENABLED:
            ctx.verify_mode = ssl.CERT_NONE
        elif ssl_mode == SSLMode.VERIFY_CA:
            ctx.verify_mode = ssl.CERT_REQUIRED
            ctx.load_verify_locations(
                cadata=base64.b64decode(info.ssl_ca.get_secret_value()).decode("utf-8")
                if info.ssl_ca
                else None
            )

        return ctx
